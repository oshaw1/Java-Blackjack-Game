package cardgame;

//this section of the code imports several different java tools that are used in the code
import java.util.Random;//this will be used to choose a random number using random later in the code
import java.util.ArrayList;//importing array lists to store the potential numbers when generated
import java.util.Scanner;//allows the code to take a input from the user
import java.util.Calendar; //importing the current date and time

public class Cardgame {

  static Calendar cal = Calendar.getInstance();
  static Random r = new Random(cal.getTimeInMillis());
  static Scanner s = new Scanner(System.in);//this allows for the system to take a user input
  // above i have got the current system time and used this in conjunction with random to generate a seemingly random number
  
  //these are the methods that will be needed in the card game and will be called on in the code
  public static ArrayList<Integer> start()
  {
    ArrayList<Integer> cards = new ArrayList<Integer>();
    for(int i = 0; i < 2; i++) // this sets the list value to 0 and then runs code until the amount of integers inside the array list is equal to 2
    {
      cards.add(draw());
    }
    return cards;
  }
  public static int draw()
  {
    int card = r.nextInt(13) + 1;//chooses a random number with a value of 13 or less and adds 1 since you cant have cards with a value of 0
    return card;//updates the value of card for it to be used in other methods
  }
  
  public static int input()
  {
    int choice = 0;
    while(choice != 1 && choice != 2)//checks what the inputs are to decide if it should be ran again or not
    {
    String next = s.next(); //runs the next random number selection
    	try{
        choice = Integer.parseInt(next);
      }
      catch(Exception e)//catches any errors in the input and runs the below println if there is any
      {
        System.out.println("that was not 1 or 2");
      }
    }
    return choice;
  }

  public static int total(ArrayList<Integer> cards)
  {
    int total = 0;// sets the total to 0 for it to be added to
    for(int card :cards)
    {
      total += card; //adds all cards values to the total variable to be outputted in a method
    }
    return total;
  }
  
  public static void main(String args[])
  {
    ArrayList<Integer> cards = start(); // this uses the start method to begin the game and pick 2 numbers
    System.out.println("your cards are " + cards.get(0) + " and " + cards.get(1) + " your total value is " +total(cards));

    if(total(cards) == 21) // checks if the value of the cards equals 21 if it does it stops the code
    {
      System.out.println("you win you got 21!");
      return;//ends the code
    }

    System.out.println("1 to draw 2 to stick");
    play(cards);//this starts the play method to draw another card
  }
  
  		public static void play(ArrayList<Integer> cards) {
  			int choice = input();//runs the input method

    	if(choice == 1)//continues only if the user chooses 1
    		{
      int newCard = draw();//runs the draw method to choose a number
      cards.add(newCard);
      System.out.println("your new card is " + newCard );//displays what number was chosen 
      		if(total(cards) == 21)
      {
        System.out.println("you win you got 21!");
        return;
      }
      		else if(total(cards) > 21)
      {
        System.out.println("you exceeded 21, try again");
        return;
      }
      else {//if the total < 21 it carries on
        System.out.println("your current cards are " + total(cards) + " press 1 or 2 again");
        play(cards);//uses the method again to make them choose 1 or 2
      }
    }

    else {
      System.out.println("your final value of cards is " + total(cards));//if the user ever chooses 2 end the progam and print the final value
      return;
    }
  }


}


